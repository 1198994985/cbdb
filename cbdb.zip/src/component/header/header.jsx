import React from 'react'
import './index.less'

export default function Header() {
  return (
    <div className="header">
      <header>
        header
      </header> 
    </div>
  )
}
