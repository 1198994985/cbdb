const menuList = [
  {
    title: '首页', // 菜单标题名称
    key: '/home', // 对应的path
    icon: 'home', // 图标名称
    isPublic: true, // 公开的
  },
  {
    title: 'cahrts',
    key: '/testCharts',
    icon: 'user'
  }
]

export default menuList